export const COMMON_CONFIG = {
    apiKey: "AIzaSyAwRrxjjft7KMdhwfLKPkd8PCBR3JFaLfo",
    authDomain: "angularfirestore.firebaseapp.com",
    databaseURL: "https://angularfirestore.firebaseio.com",
    projectId: "angularfirestore",
    storageBucket: "angularfirestore.appspot.com",
    messagingSenderId: "1039984584356"
};
//# sourceMappingURL=test-config.js.map