export declare function validateEventsArray(events?: any[]): any[] | undefined;
