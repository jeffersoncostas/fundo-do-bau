export declare const COMMON_CONFIG: {
    apiKey: string;
    authDomain: string;
    databaseURL: string;
    storageBucket: string;
};
