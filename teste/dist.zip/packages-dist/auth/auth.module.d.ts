import '@firebase/auth';
export declare class AngularFireAuthModule {
}
