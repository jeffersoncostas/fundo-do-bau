import './auth.spec';
//# sourceMappingURL=index.spec.js.map