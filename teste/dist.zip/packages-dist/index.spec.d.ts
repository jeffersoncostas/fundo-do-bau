import './angularfire2.spec';
