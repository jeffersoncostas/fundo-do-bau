import './angularfire2.spec';
//# sourceMappingURL=index.spec.js.map